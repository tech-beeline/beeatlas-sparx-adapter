# Interface Agreement
## Документация
- README.md

## IAs
- /Папка_провайдера/IA/Папка_потребителя **IAs по продуктам**

## Добавление файлов your files




1. Склонируйте удаленный репозиторий
```
cd existing_repo
git remote add origin https://git.vimpelcom.ru/common/architecture/interface-agreement.git
git branch -M main
git push -uf origin main
```
2. Создайте отдельную ветку (branch) для своего IA.

3. Создать папку для своего приложения - провайдера TC, в ней папку IA, далее папку потребителя, например interface-agreement/Digital Contract/IA/BeeLego

4. Загрузите YAML файл по шаблону IA.
